# Examen Java 1732 — Variante B (alternativa independiente)

## 1. La restricción de nombres más importante
La guía del docente (página 3) indica expresamente que bajo
`src/main/java/com/carmotors/servicio/observer/` deben existir las cuatro
clases **Sujeto, Observador, ObservadorLogServicio y ObservadorNotificacionCliente**.
Por eso permanecen con esos nombres: renombrarlas sería arriesgar puntos.

Esta variante cambia el nombre del record a `AvisoOrdenFinalizada`, el del
ejecutable de pruebas a `PruebaAvisosObserver1732`, y la implementación real:
- `ArrayList` más sincronización/copia de suscriptores (en lugar de CopyOnWriteArrayList).
- `PrintStream` inyectable para comprobar el LOG.
- `BufferedWriter` de Java NIO con CREATE y APPEND, sin sobrescribir avisos.
- Un método de vista `finalizarDesdeConsola()` distinto de la variante anterior.

## 2. Flujo desde Main
1. Main crea `ClienteDAO` y el `OrdenServicioService` actual con la dependencia DAO extra.
2. Main registra `ObservadorLogServicio` y `ObservadorNotificacionCliente` **una sola vez**.
3. Administrador → Órdenes de servicio → Completar Orden de Servicio.
4. VistaOrdenes lee el ID y confirma. Invoca `OrdenServicioController.cambiarEstado(id,"Completado")`.
5. OrdenServicioService bloquea la orden, consume los repuestos, actualiza el estado y
   obtiene el nombre con ClienteDAO en la misma conexión.
6. `commit()`; solo después se llama `notificarObservadores(aviso)`.
7. Consola: `LOG: El servicio # 11 para el vehículo ABC123 ha sido completado.`
8. Raíz: `notificaciones_clientes.txt`, una línea por evento, con fecha, nombre y placa.

**Prohibido** notificar antes del commit, porque un rollback no debe avisar al cliente.
No se modifica el esquema, no hay SQL en Vista ni en los observadores.

## 3. Instalación en el repositorio personal
La guía específica exige un **repositorio público personal** llamado
`examen-java-1732`, desarrollo directamente en `main` y entrega de la URL.
No cambiar la rama `developer` del proyecto grupal ni publicar credenciales reales.

En la copia personal verifica primero:
```
git status
git branch --show-current
git rev-parse HEAD
```

En una copia limpia de la `main` compatible del proyecto:
```
git apply --check /RUTA/parche_examen_1732_variante_B.patch
git apply /RUTA/parche_examen_1732_variante_B.patch
```

Si la comprobación falla, **no usar --force ni reemplazar Main completo**:
revisar conflictos con el HEAD actual. Los archivos completos del ZIP son
material de referencia para adaptar los cambios.

Actualizar `COMPLETAR_NOMBRE` y `COMPLETAR_GRUPO` en `README.md`.
Desde IntelliJ ejecutar `PruebaAvisosObserver1732.main()` sin MySQL.
Luego probar `com.carmotors.Main` con MySQL local de pruebas, completar una
orden realmente En Proceso y verificar el archivo en la raíz de ejecución.
Nunca ejecutar `database/schema.sql` sobre una base con información valiosa;
el script del proyecto recrea la base de pruebas.

## 4. Casos obligatorios
- Una orden En Proceso se completa → se confirma y notifica por ambos canales.
- Otra transición no genera aviso; una segunda finalización se rechaza.
- Un error DAO o de commit provoca rollback y **cero notificaciones**.
- Un archivo inexistente se crea y otro existente recibe una nueva línea.
- Registrar el mismo observador dos veces no duplica el evento.
- Si falla un observador, se notifica a los demás; ya no puede hacerse rollback.
- La prueba real necesita un cliente existente y reservas coherentes.

## 5. Argumentos de la sustentación
**Sujeto**: OrdenServicioService, porque él conoce la transición confirmada.
**Observer**: los receptores implementan una interfaz y pueden añadirse sin
modificar el flujo transaccional (OCP/DIP).
**SRP**: el log imprime, el TXT almacena, DAO consulta, Vista presenta.
**Evento record**: transporte inmutable de datos, no entidad persistida.
**Sincronización**: la lista de suscriptores admite copia segura antes de avisar.
**Fallo de TXT**: no revierte la orden; se registra el problema en stderr.

## 6. Restricción conocida
No existe mecanismo persistente de reintento de notificaciones fallidas:
es una primera fase académica que genera borradores, no una cola fiable de envíos.
