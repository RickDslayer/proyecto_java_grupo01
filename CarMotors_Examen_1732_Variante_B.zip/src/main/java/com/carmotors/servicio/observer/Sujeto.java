package com.carmotors.servicio.observer;

import com.carmotors.modelo.AvisoOrdenFinalizada;

/** Contrato explícito requerido por el examen 1732. */
public interface Sujeto {
    void registrarObservador(Observador observador);
    void removerObservador(Observador observador);
    void notificarObservadores(AvisoOrdenFinalizada aviso);
}
