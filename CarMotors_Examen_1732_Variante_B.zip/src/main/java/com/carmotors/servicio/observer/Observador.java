package com.carmotors.servicio.observer;

import com.carmotors.modelo.AvisoOrdenFinalizada;

/** El canal no conoce MySQL ni necesita saber quién originó el evento. */
@FunctionalInterface
public interface Observador {
    void actualizar(AvisoOrdenFinalizada aviso);
}
