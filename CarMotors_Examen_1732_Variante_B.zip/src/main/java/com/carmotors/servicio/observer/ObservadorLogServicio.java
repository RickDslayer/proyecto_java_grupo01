package com.carmotors.servicio.observer;

import com.carmotors.modelo.AvisoOrdenFinalizada;
import java.io.PrintStream;
import java.util.Objects;

/** Observador 1: registra la finalización en la consola del taller. */
public final class ObservadorLogServicio implements Observador {
    private final PrintStream salida;

    public ObservadorLogServicio() {
        this(System.out);
    }

    /** Permite redirigir la salida en una prueba sin tocar System.out. */
    public ObservadorLogServicio(PrintStream salida) {
        this.salida = Objects.requireNonNull(salida, "La salida es obligatoria.");
    }

    @Override
    public void actualizar(AvisoOrdenFinalizada aviso) {
        Objects.requireNonNull(aviso, "El aviso es obligatorio.");
        salida.println("LOG: El servicio # " + aviso.servicioId()
                + " para el vehículo " + aviso.placa() + " ha sido completado.");
    }
}
