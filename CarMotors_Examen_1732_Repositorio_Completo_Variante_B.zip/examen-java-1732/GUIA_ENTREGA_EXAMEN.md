# Examen Java 1732 · Variante B · Repositorio completo

## Qué incluye

Esta carpeta incluye `src/main`, `src/test`, `database`, `docs`, `pom.xml`,
`README.md` y `.gitignore`, con el Observer de la variante B **ya integrado**.
No incluye `.git`, `.idea` ni `target`, pues son metadatos y productos generados.

## Procedencia

La base es el ZIP original facilitado por el estudiante (`feature/Vistas_Main`,
commit `1c44ed81`). Esta base **es anterior a la main remota** y todavía puede
carecer de mejoras posteriores, por ejemplo la exportación de facturas o cobros.
El objetivo del paquete es ser autocontenido sobre la fuente que el estudiante
adjuntó, no afirmar que es un espejo de GitHub main.

## Prueba autónoma

En IntelliJ, selecciona JDK 17 y abre `pom.xml` como proyecto Maven.
Abre `src/test/java/com/carmotors/PruebaAvisosObserver1732.java` y ejecuta su método `main()`.

## Recorrido funcional real

1. Configura MySQL local con `database/schema.sql` y `database/data.sql`.
   **No** ejecutes `schema.sql` sobre una base con datos que necesites conservar;
   el esquema de prueba puede recrearse.
2. Ejecuta `com.carmotors.Main`, con directorio de trabajo en la raíz.
3. Administrador → Atención y órdenes de servicio → `Completar Orden de Servicio`.
4. Selecciona una orden `En Proceso` que tenga reservas coherentes y confirma.
5. Verifica que se hizo `commit`, apareció el LOG y se creó
   `notificaciones_clientes.txt` con una línea; al completar otra orden, comprueba APPEND.
6. Intenta completar de nuevo la misma orden y comprueba que no se repite el aviso.

## Qué ocurre si falla una operación

Si falla el consumo o el cambio de estado, el Service hace rollback y los
observadores no deben recibir el evento. Si falla escribir el TXT, la orden ya
fue confirmada; el Service aísla errores del observador.

## Entrega oficial

La guía de examen pide repositorio personal **público** `examen-java-1732`,
rama `main`, README final con estudiante y grupo. NO copies la carpeta `.git`
del proyecto grupal; crea el repositorio personal independiente.

## Nombres requeridos

Por exigencia del docente, las cuatro clases del paquete `servicio.observer`
se llaman `Sujeto`, `Observador`, `ObservadorLogServicio` y
`ObservadorNotificacionCliente`. La diferencia de variante reside en la
implementación y en el tipo de evento, no en cambiar esos contratos obligatorios.
