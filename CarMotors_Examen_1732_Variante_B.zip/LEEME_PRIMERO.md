# Entrega variante B del examen 1732

Este ZIP contiene **solamente los archivos creados/cambiados** para un proyecto
CarMotors existente. No contiene el repositorio entero. La forma más segura es
aplicar `parche_examen_1732_variante_B.patch` en la raíz de la copia personal.

**No mezclar** esta variante con la A: ambas definen los mismos cuatro tipos
obligatorios y usan records de nombres distintos.

Los cuatro archivos `Sujeto.java`, `Observador.java`, `ObservadorLogServicio.java`,
`ObservadorNotificacionCliente.java` NO se pueden renombrar porque la guía del
profesor exige esos nombres. Cambian el record y el archivo de prueba.

`REFERENCIA_NO_SOBRESCRIBIR/Main_ensamblaje_ejemplo.java.txt` es un ejemplo
completo anterior, no el Main más reciente. NO reemplazar el archivo actual.
Usar `FRAGMENTO_MAIN.md` o el parche para registrar los observadores.

Consultar `GUIA_VARIANTE_B.md` y completar el nombre/grupo en el README. La guía
del docente solicita un repositorio personal público en rama main.
