package com.carmotors.servicio.observer;

import com.carmotors.modelo.AvisoOrdenFinalizada;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/** Observador 2: añade un borrador al historial de notificaciones, sin enviar SMS. */
public final class ObservadorNotificacionCliente implements Observador {
    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private final Path destino;

    public ObservadorNotificacionCliente() {
        this(Path.of("notificaciones_clientes.txt"));
    }

    public ObservadorNotificacionCliente(Path destino) {
        this.destino = Objects.requireNonNull(destino, "El archivo es obligatorio.");
    }

    @Override
    public synchronized void actualizar(AvisoOrdenFinalizada aviso) {
        Objects.requireNonNull(aviso, "El aviso es obligatorio.");
        String mensaje = "[" + FECHA.format(aviso.fechaHora()) + "] - NOTIFICACIÓN PARA "
                + normalizar(aviso.nombreCliente()) + ": Su vehículo con placa "
                + normalizar(aviso.placa()) + " está listo para ser recogido.";
        try (BufferedWriter escritor = Files.newBufferedWriter(destino, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND)) {
            escritor.write(mensaje);
            escritor.newLine();
        } catch (IOException error) {
            throw new UncheckedIOException("No fue posible registrar el aviso en " + destino, error);
        }
    }

    private static String normalizar(String texto) {
        return texto.replace('\r', ' ').replace('\n', ' ');
    }
}
