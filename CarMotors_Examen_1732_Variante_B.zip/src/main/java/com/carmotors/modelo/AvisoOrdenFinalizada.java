package com.carmotors.modelo;

import java.time.LocalDateTime;
import java.util.Objects;

/** Datos inmutables para los distintos canales que reaccionan al cierre de una orden. */
public record AvisoOrdenFinalizada(
        int servicioId,
        int vehiculoId,
        String placa,
        int clienteId,
        String nombreCliente,
        LocalDateTime fechaHora
) {
    public AvisoOrdenFinalizada {
        if (servicioId <= 0 || vehiculoId <= 0 || clienteId <= 0) {
            throw new IllegalArgumentException("Los identificadores deben ser positivos.");
        }
        Objects.requireNonNull(fechaHora, "La fecha de finalización es obligatoria.");
        if (placa == null || placa.isBlank() || nombreCliente == null || nombreCliente.isBlank()) {
            throw new IllegalArgumentException("La placa y el nombre del cliente son obligatorios.");
        }
        placa = placa.strip();
        nombreCliente = nombreCliente.strip();
    }
}
