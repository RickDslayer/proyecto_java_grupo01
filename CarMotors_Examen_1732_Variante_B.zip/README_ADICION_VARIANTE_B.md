### Examen final 1732 | Notificación de órdenes completadas mediante Observer

Estudiante y grupo: **COMPLETAR_NOMBRE** | **COMPLETAR_GRUPO**
Proyecto de origen: https://github.com/RickDslayer/proyecto_java_grupo01
Acceso: `com.carmotors.Main` → Administrador → Órdenes de servicio → **Completar Orden de Servicio**.
Clases nuevas: `com.carmotors.servicio.observer.Sujeto`, `Observador`,
`ObservadorLogServicio`, `ObservadorNotificacionCliente` y
`com.carmotors.modelo.AvisoOrdenFinalizada`.
Clases ajustadas: `OrdenServicioService`, `Main`, `VistaOrdenes`.

`OrdenServicioService` es el sujeto concreto. Cuando confirma la transición
`En Proceso → Completado` y el descuento de reservas, construye un aviso
inmutable con el nombre del cliente y la placa. **Solo después del commit**
invoca a los observadores registrados una vez desde Main:
- `ObservadorLogServicio`: imprime el registro en consola.
- `ObservadorNotificacionCliente`: escribe al final de `notificaciones_clientes.txt`
  en UTF-8, creando el archivo cuando hace falta.

Las notificaciones son borradores locales; no se envía WhatsApp ni SMS.
Un fallo de un canal no deshace la transacción ni bloquea los demás canales.
