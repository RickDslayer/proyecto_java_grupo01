# Cambios mínimos en el Main actual

Busca esta construcción de `OrdenServicioService`:

```java
OrdenServicioService ordenService = new OrdenServicioService(
        ordenDao, new VehiculoConsultaImpl(vehiculoDao), conexiones, reloj,
        reservas, facturacion, publicador);
```

Sustitúyela por:

```java
OrdenServicioService ordenService = new OrdenServicioService(
        ordenDao, new VehiculoConsultaImpl(vehiculoDao), conexiones, reloj,
        reservas, facturacion, publicador, clienteDao);
ordenService.registrarObservador(
        new com.carmotors.servicio.observer.ObservadorLogServicio(System.out));
ordenService.registrarObservador(
        new com.carmotors.servicio.observer.ObservadorNotificacionCliente());
```

El `clienteDao` ya existe en `Main`. La instancia `ordenService` debe ser
la misma que se pasa a `OrdenServicioController`.

**No reemplaces `Main.java` completo si tu equipo lo ha actualizado.**
Usa el parche o inserta estas líneas en el archivo más reciente.
